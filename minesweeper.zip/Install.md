# Install Instructions

Minesweeper, Fall 2021, for Cornell CS3110. Max Pace, Arjun Shah, Jerry Xu.

## MS1

We have used no additional packages from OPAM outside of those used for A1 and A2. Namely, we have used ANSI Terminal and OUnit 2. Install instructions for those can be found on the course assignment pages, namely [here for A2, for ANSI Terminal](https://www.cs.cornell.edu/courses/cs3110/2021fa/a2/).

### Building code

You can compile the code by running `make build`.
