let hours_worked = -1
